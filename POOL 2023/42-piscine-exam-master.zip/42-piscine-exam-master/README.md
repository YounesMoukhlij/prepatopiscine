# C Exam Alone In The Dark - Beginner

The solutions to 42's exam exercises

The exercises of **Level 0**: [Level_00](https://github.com/barimehdi77/42-piscine-exam/tree/master/Level_00)

The exercises of **Level 1**: [Level_01](https://github.com/barimehdi77/42-piscine-exam/tree/master/Level_01)

The exercises of **Level 2**: [Level_02](https://github.com/barimehdi77/42-piscine-exam/tree/master/Level_02)

The exercises of **Level 3**: [Level_03](https://github.com/barimehdi77/42-piscine-exam/tree/master/Level_03)

The exercises of **Level 4**: [Level_04](https://github.com/barimehdi77/42-piscine-exam/tree/master/Level_04)

The exercises of **Level 5**: [Level_05](https://github.com/barimehdi77/42-piscine-exam/tree/master/Level_05)

Good luck in The exams :)

---

[!["Buy Me A Coffee"](https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png)](https://www.buymeacoffee.com/barimehdi77)
[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/K3K45UOA7)
[![paypal](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://paypal.me/barimehdi77)
